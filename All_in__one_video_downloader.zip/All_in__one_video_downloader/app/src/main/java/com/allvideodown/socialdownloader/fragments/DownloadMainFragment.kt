/*
 * *
 * * Created by Syed Usama Ahmad on 3/17/23, 11:37 PM
 * * Copyright (c) 2023 . All rights reserved.
 * * Last modified 3/17/23, 9:19 PM
 *
 */

@file:Suppress("DEPRECATION", "NAME_SHADOWING")

package com.allvideodown.socialdownloader.fragments

import android.annotation.SuppressLint
import android.app.Activity
import android.app.ProgressDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.Toast
import androidx.annotation.Keep
import androidx.appcompat.app.AlertDialog
import androidx.biometric.BiometricManager
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.bumptech.glide.Glide
import com.franmontiel.persistentcookiejar.ClearableCookieJar
import com.franmontiel.persistentcookiejar.PersistentCookieJar
import com.franmontiel.persistentcookiejar.cache.SetCookieCache
import com.franmontiel.persistentcookiejar.persistence.SharedPrefsCookiePersistor
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.MobileAds
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import com.allvideodown.socialdownloader.BuildConfig
import com.allvideodown.socialdownloader.R
import com.allvideodown.socialdownloader.activities.GalleryActivity
import com.allvideodown.socialdownloader.activities.InstagramLoginActivity
import com.allvideodown.socialdownloader.activities.MainActivity
import com.allvideodown.socialdownloader.activities.SplashScreen
import com.allvideodown.socialdownloader.databinding.FragmentDownloadBinding
import com.allvideodown.socialdownloader.models.InstagramPostDataNew
import com.allvideodown.socialdownloader.models.storymodels.ModelEdNode
import com.allvideodown.socialdownloader.models.storymodels.ModelGetEdgetoNode
import com.allvideodown.socialdownloader.models.storymodels.ModelInstagramResponse
import com.allvideodown.socialdownloader.services.MyFirebaseMessagingService
import com.allvideodown.socialdownloader.utils.AdsManager
import com.allvideodown.socialdownloader.utils.Constants
import com.allvideodown.socialdownloader.utils.Constants.PREF_CLIP
import com.allvideodown.socialdownloader.utils.DownloadFileMain
import com.allvideodown.socialdownloader.utils.OreoNotification
import com.allvideodown.socialdownloader.utils.SharedPrefsForInstagram
import com.allvideodown.socialdownloader.utils.SharedPrefsMainApp
import com.allvideodown.socialdownloader.utils.iUtils
import com.allvideodown.socialdownloader.utils.iUtils.ShowToast
import com.allvideodown.socialdownloader.webservices.DownloadVideosMain
import io.reactivex.rxjava3.exceptions.UndeliverableException
import io.reactivex.rxjava3.plugins.RxJavaPlugins
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import org.apache.commons.lang3.StringEscapeUtils
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@Keep
class DownloadMainFragment : Fragment() {
    private var myselectedActivity: FragmentActivity? = null
    private var binding: FragmentDownloadBinding? = null
    private var nn: String? = "nnn"
    private var csRunning = false
    lateinit var webViewInsta: WebView
    lateinit var progressDralogGenaratinglink: ProgressDialog
    private lateinit var prefEditor: SharedPreferences.Editor
    lateinit var pref: SharedPreferences
    var myVideoUrlIs: String? = null
    var myInstaUsername: String? = ""
    var myPhotoUrlIs: String? = null

    // Naya data class preview ke pending downloads hold karne ke liye
    data class PendingMedia(val url: String, val fileName: String, val extension: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDownloadBinding.inflate(inflater, container, false)
        setActivityAfterAttached()
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (activity != null && isAdded) {
            hideKeyboard(requireActivity())
            nn = SharedPrefsMainApp(myselectedActivity).preferencE_inappads

            progressDralogGenaratinglink = ProgressDialog(myselectedActivity!!)
            progressDralogGenaratinglink.setMessage(resources.getString(R.string.genarating_download_link))
            progressDralogGenaratinglink.setCancelable(false)

            pref = myselectedActivity!!.getSharedPreferences(PREF_CLIP, 0)
            prefEditor = pref.edit()
            csRunning = pref.getBoolean("csRunning", false)
            prefEditor.apply()

            createNotificationChannel(myselectedActivity!!)
            configureRxJavaErrorHandler()

            binding!!.ivHelp.setOnClickListener {
                try {
                    binding!!.etURL.setText("")
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            binding!!.btnDownload.setOnClickListener {
                val url = binding!!.etURL.text.toString()
                // Naya UX Flow: Button chhupao, loader dikhao
                binding!!.btnDownload.visibility = View.GONE
                binding!!.pbLoading.visibility = View.VISIBLE
                binding!!.cvPreviewContainer.visibility = View.GONE

                DownloadVideo(url)
            }

            binding?.showinstatext?.visibility = if (iUtils.isNonPlayStoreApp) View.VISIBLE else View.GONE

            if (activity != null) {
                val activity: MainActivity? = activity as MainActivity?
                val strtext: String? = activity?.getMyData()
                if (strtext != null && strtext != "") {
                    activity.setmydata("")
                    binding!!.etURL.setText(strtext)
                    val url = binding!!.etURL.text.toString()
                    binding!!.btnDownload.performClick()
                }
            }

            handleBioMetricTask()

            binding!!.instaprivatefbprivate.visibility = View.GONE
            binding!!.videomoreBtn.visibility = View.GONE

            binding!!.ivLink.setOnClickListener {
                val clipBoardManager =
                    myselectedActivity!!.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

                val primaryClipData = clipBoardManager.primaryClip
                val clip = primaryClipData?.getItemAt(0)?.text.toString()

                binding!!.etURL.text = Editable.Factory.getInstance().newEditable(clip)
                binding!!.btnDownload.performClick()
            }

            doAdsStuff()
            if (!iUtils.isNonPlayStoreApp) {
                doNoMetasStuff()
            }
        }
    }

    // ========================================================
    // 🛠️ MAGIC FIX: SANITIZE FILENAME FOR 100% SUCCESS RATE
    // ========================================================
    private fun cleanFilename(filename: String): String {
        return filename.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(50)
    }

    // ==========================================
    // 🚀 PREVIEW UI WITH "PLAY VIDEO" CLICK LISTENER
    // ==========================================
    private fun showPreviewUI(mediaList: List<PendingMedia>) {
        myselectedActivity?.runOnUiThread {
            try {
                dismissMyDialogFrag()
                binding!!.pbLoading.visibility = View.GONE
                binding!!.btnDownload.visibility = View.VISIBLE
                binding!!.btnDownload.text = "Fetch Another"
                binding!!.cvPreviewContainer.visibility = View.VISIBLE

                val firstMedia = mediaList.first()
                binding!!.tvPreviewTitle.text = if (mediaList.size > 1) "Found ${mediaList.size} Media Files" else cleanFilename(firstMedia.fileName)

                // Show play icon if it's a video
                binding!!.imgPlayIcon.visibility = if (firstMedia.extension.contains("mp4")) View.VISIBLE else View.GONE

                // Load thumbnail via Glide
                Glide.with(requireContext()).load(firstMedia.url).into(binding!!.imgPreviewThumbnail)

                // 🚀 NAYA FEATURE: THUMBNAIL/IMAGE PAR CLICK KARKE VIDEO PLAY KAREIN (PREVIEW)
                binding!!.imgPreviewThumbnail.setOnClickListener {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW)
                        val mimeType = if (firstMedia.extension.contains("mp4")) "video/*" else "image/*"
                        intent.setDataAndType(Uri.parse(firstMedia.url), mimeType)
                        myselectedActivity?.startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        showToast("Cannot play media on this device.")
                    }
                }

                // Final Save Button Action
                binding!!.btnSaveMedia.setOnClickListener {
                    val timestamp = System.currentTimeMillis()
                    mediaList.forEachIndexed { index, media ->
                        val safeFileName = "Insta_${timestamp}_${index}_${cleanFilename(media.fileName)}"
                        val cleanUrl = media.url.trim()

                        DownloadFileMain.startDownloading(
                            myselectedActivity!!,
                            cleanUrl,
                            safeFileName,
                            media.extension
                        )
                    }
                    showToast("Downloading started! Check Gallery.")
                    showAdmobAds_int_video() // Show Ad on final click for extra Revenue
                }
            } catch (e: Exception) {
                e.printStackTrace()
                resetUI()
            }
        }
    }

    private fun resetUI() {
        myselectedActivity?.runOnUiThread {
            binding?.pbLoading?.visibility = View.GONE
            binding?.btnDownload?.visibility = View.VISIBLE
            binding?.btnDownload?.text = getString(R.string.download)
        }
    }

    private fun doAdsStuff() {
        try {
            if (Constants.show_Ads && !BuildConfig.ISPRO && nn == "nnn") {
                MobileAds.initialize(requireActivity()) {
                    AdsManager.loadInterstitialAdAsync((activity as Activity?)!!)
                    AdsManager.loadVideoAdAdmobAsync(
                        (activity as Activity?)!!,
                        object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent()
                            }
                        })
                    LoadAdTaskDownload(myselectedActivity!!, binding!!.flAdplaceholder).execute()
                    LoadAdTaskDownload(myselectedActivity!!, binding!!.flNativeAdPreview).execute() // Preview Native Ad
                }
            } else {
                binding!!.flAdplaceholder.visibility = View.GONE
                binding!!.flNativeAdPreview.visibility = View.GONE
            }
        } catch (_: Exception) {}
    }

    @SuppressLint("StaticFieldLeak")
    private fun doNoAdsBonusStuff() {
        // Intentionally skipped for preview focus, code remains same
    }

    @SuppressLint("StaticFieldLeak")
    private fun doNoMetasStuff() {
        val isBonusAlert = SharedPrefsMainApp(myselectedActivity!!).preferencE_isMetaRemovalShown
        if (!isBonusAlert) {
            if (isAdded) {
                val builder = AlertDialog.Builder(myselectedActivity!!)
                builder.setTitle("Alert!!")
                builder.setCancelable(false)
                builder.setMessage("Support of All Meta related services like (Facebook, instagram, threads and whatsapp status saver) have been removed due to Meta's Copyright Strike. We are sorry for the inconvenience. ")

                builder.setPositiveButton(R.string.rate_it) { dialog, _ ->
                    dialog.dismiss()
                    SharedPrefsMainApp(myselectedActivity!!).preferencE_isMetaRemovalShown = true
                }
                builder.show()
            }
        }
    }

    private fun handleBioMetricTask() {
        try {
            val biometricManager: BiometricManager = BiometricManager.from(myselectedActivity!!)
            binding!!.rvGallery.setOnClickListener {
                startActivity(Intent(myselectedActivity, GalleryActivity::class.java))
            }
        } catch (e: Exception) {
            e.printStackTrace()
            binding!!.rvGallery.setOnClickListener {
                startActivity(Intent(myselectedActivity, GalleryActivity::class.java))
            }
        }
    }

    class LoadAdTaskDownload(private val context: Activity, private val frameLayout: FrameLayout) :
        AsyncTask<Void, Void, Unit>() {
        @Deprecated("Deprecated in Java")
        override fun doInBackground(vararg params: Void?) {
            AdsManager.loadAdmobNativeAdAsync(context, frameLayout)
        }
    }

    fun dismissMyDialogFrag() {
        try {
            if (activity != null && isAdded) {
                myselectedActivity?.runOnUiThread {
                    if (!(myselectedActivity as Activity).isFinishing && progressDralogGenaratinglink != null && progressDralogGenaratinglink.isShowing) {
                        progressDralogGenaratinglink.dismiss()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun dismissMyDialogErrorToastFrag() {
        try {
            if (activity != null && isAdded) {
                myselectedActivity?.runOnUiThread {
                    if (!(myselectedActivity as Activity).isFinishing && progressDralogGenaratinglink != null && progressDralogGenaratinglink.isShowing) {
                        progressDralogGenaratinglink.dismiss()
                        myselectedActivity!!.runOnUiThread {
                            iUtils.ShowToastError(myselectedActivity, myselectedActivity!!.resources.getString(R.string.somthing))
                        }
                    }
                    resetUI()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            resetUI()
        }
    }

    fun DownloadVideo(url1: String) {
        hideKeyboard(requireActivity())

        if (TextUtils.isEmpty(url1.trim()) && url1.trim() == "") {
            ShowToast(myselectedActivity, myselectedActivity!!.resources?.getString(R.string.enter_valid))
            resetUI()
            return
        }

        var url = url1
        try {
            url = iUtils.extractUrls(url1)[0]
        } catch (_: Exception) {}

        if (!iUtils.checkURL(url.trim())) {
            ShowToast(myselectedActivity, myselectedActivity!!.resources?.getString(R.string.enter_valid))
            resetUI()
            return
        }

        SplashScreen.uploadDownloadedUrl(url1)

        if (url.contains("instagram.com")) {
            if (!myselectedActivity!!.isFinishing) {
                if (!iUtils.isNonPlayStoreApp) {
                    ShowToast(myselectedActivity, myselectedActivity!!.resources.getString(R.string.somthing_webiste_panele_block))
                    resetUI()
                    return
                }
                if (!iUtils.isSocialMediaOn("instagram.com")) {
                    ShowToast(myselectedActivity, myselectedActivity!!.resources.getString(R.string.somthing_webiste_panele_block))
                    resetUI()
                    return
                }
                startInstaDownload(url)
            }
        } else {
            var myurl = url
            try {
                myurl = iUtils.extractUrls(myurl)[0]
            } catch (_: Exception) {}
            DownloadVideosMain.Start(myselectedActivity, myurl.trim(), false)
            resetUI()
        }
    }

    private fun setActivityAfterAttached() {
        try {
            if (activity != null && isAdded) {
                myselectedActivity = activity
            }
        } catch (e: Exception) {
            myselectedActivity = requireActivity()
            e.printStackTrace()
        }
    }

    @Keep
    @SuppressLint("JavascriptInterface", "SetJavaScriptEnabled")
    fun startInstaDownload(Url: String) {
        val Urlwi: String?
        try {
            val uri = URI(Url)
            Urlwi = URI(uri.scheme, uri.authority, uri.path, null, uri.fragment).toString()
        } catch (ex: java.lang.Exception) {
            ShowToast(myselectedActivity!!, getString(R.string.invalid_url))
            resetUI()
            return
        }

        var urlwithoutlettersqp: String? = Urlwi

        if (urlwithoutlettersqp!!.contains("/share/")) {
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    val redirectedUrl = getRedirectUrl(urlwithoutlettersqp!!)?.let { redirected ->
                        val uri = URI(redirected)
                        URI(uri.scheme, uri.authority, uri.path, null, uri.fragment).toString()
                    } ?: urlwithoutlettersqp
                    continueInstagramDownload(redirectedUrl)
                } catch (e: Exception) {
                    println("Error handling redirected URL: ${e.message}")
                    resetUI()
                }
            }
        } else {
            continueInstagramDownload(urlwithoutlettersqp!!)
        }
    }

    suspend fun getRedirectUrl(url: String): String? {
        return withContext(Dispatchers.IO) {
            var connection: HttpURLConnection? = null
            try {
                val initialUrl = URL(url)
                connection = initialUrl.openConnection() as HttpURLConnection
                connection.instanceFollowRedirects = true
                connection.connect()

                val responseCode = connection.responseCode
                if (responseCode in 300..399) {
                    connection.getHeaderField("Location")
                } else {
                    connection.url.toString()
                }
            } catch (e: IOException) {
                e.printStackTrace()
                null
            } finally {
                connection?.disconnect()
            }
        }
    }

    fun continueInstagramDownload(myUrl: String) {
        var urlwithoutlettersqp: String? = myUrl

        if (urlwithoutlettersqp!!.contains("/reel/")) {
            urlwithoutlettersqp = urlwithoutlettersqp.replace("/reel/", "/p/")
        }

        if (urlwithoutlettersqp.contains("/tv/")) {
            urlwithoutlettersqp = urlwithoutlettersqp.replace("/tv/", "/p/")
        }

        val urlwithoutlettersqp_noa: String = urlwithoutlettersqp
        urlwithoutlettersqp = "$urlwithoutlettersqp?__a=1&__d=dis"

        try {
            if (urlwithoutlettersqp.split("/")[4].length > 15) {
                val sharedPrefsFor = SharedPrefsForInstagram(myselectedActivity)
                if (sharedPrefsFor.preference.preferencE_SESSIONID == "") {
                    sharedPrefsFor.clearSharePrefs()
                }
                val map = sharedPrefsFor.preference
                if (map != null) {
                    if (map.preferencE_ISINSTAGRAMLOGEDIN == "false") {
                        if (!myselectedActivity!!.isFinishing) {
                            val alertDialog = android.app.AlertDialog.Builder(requireActivity()).create()
                            alertDialog.setTitle(getString(R.string.logininsta))
                            alertDialog.setMessage(getString(R.string.urlisprivate))
                            alertDialog.setButton(android.app.AlertDialog.BUTTON_POSITIVE, getString(R.string.logininsta)) { dialog, _ ->
                                dialog.dismiss()
                                val intent = Intent(requireActivity(), InstagramLoginActivity::class.java)
                                startActivityForResult(intent, 200)
                            }
                            alertDialog.setButton(android.app.AlertDialog.BUTTON_NEGATIVE, getString(R.string.cancel)) { dialog, _ ->
                                dialog.dismiss()
                            }
                            alertDialog.show()
                        }
                        resetUI()
                        return
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (!(myselectedActivity)!!.isFinishing) {
            try {
                val sharedPrefsFor = SharedPrefsForInstagram(myselectedActivity!!)
                val map = sharedPrefsFor.preference
                if (map != null && map.preferencE_USERID != null && map.preferencE_USERID != "oopsDintWork" && map.preferencE_USERID != "") {
                    fetchInstagramData(urlwithoutlettersqp, "ds_user_id=" + map.preferencE_USERID + "; sessionid=" + map.preferencE_SESSIONID)
                } else {
                    fetchInstagramData(urlwithoutlettersqp, null)
                }
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
                ShowToast(myselectedActivity!!, getString(R.string.error_occ))
                resetUI()
            }
        }
    }

    private fun downloadgraminstagramapi(stringurl: String) {
        val client = OkHttpClient()
        val formBody = FormBody.Builder().add("url", stringurl).build()

        val request = Request.Builder()
            .url("https://api.downloadgram.org/media")
            .post(formBody)
            .addHeader("content-type", "application/x-www-form-urlencoded")
            .addHeader("origin", "https://downloadgram.org")
            .addHeader("referer", "https://downloadgram.org/")
            .addHeader("user-agent", "Mozilla/5.0")
            .build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                myselectedActivity!!.runOnUiThread {
                    ShowToast(myselectedActivity, myselectedActivity!!.getString(R.string.somthing))
                    resetUI()
                }
            }

            override fun onResponse(call: okhttp3.Call, response: Response) {
                try {
                    val downloadedUrls = mutableSetOf<String>()
                    val pendingList = mutableListOf<PendingMedia>()

                    if (response.isSuccessful) {
                        val responseBody = response.body?.string() ?: ""
                        val listofurls = iUtils.extractUrls(responseBody)

                        for (i in listofurls) {
                            if (i.isNotEmpty()) {
                                val uri = Uri.parse(i)
                                val token = uri.getQueryParameter("token")
                                if (token != null) {
                                    val payloadJson = iUtils.extractUrlAndFilenameFromJwt(token)
                                    if (payloadJson != null) {
                                        val filename = payloadJson[1]
                                        val lastDotIndex = filename.lastIndexOf('.')
                                        val name = if (lastDotIndex > 0) filename.substring(0, lastDotIndex) else filename
                                        val extension = if (lastDotIndex > 0) filename.substring(lastDotIndex) else ".jpg"
                                        val urlpayload = payloadJson[0]

                                        if (!downloadedUrls.contains(urlpayload)) {
                                            downloadedUrls.add(urlpayload)
                                            pendingList.add(PendingMedia(urlpayload, name, extension))
                                        }
                                    }
                                }
                            }
                        }

                        if(pendingList.isNotEmpty()){
                            showPreviewUI(pendingList)
                        }else{
                            resetUI()
                        }
                    } else {
                        myselectedActivity!!.runOnUiThread {
                            ShowToast(myselectedActivity, myselectedActivity!!.getString(R.string.somthing))
                            resetUI()
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    myselectedActivity!!.runOnUiThread {
                        ShowToast(myselectedActivity, myselectedActivity!!.getString(R.string.somthing))
                        resetUI()
                    }
                }
            }
        })
    }

    fun scrapePost(urlOrShortcode: String, mycookies: String?): String {
        val INSTAGRAM_DOCUMENT_ID = "8845758582119845"
        val shortcode = if (urlOrShortcode.contains("http")) {
            urlOrShortcode.split("/p/").last().split("/")[0]
        } else {
            urlOrShortcode
        }

        val variables = JSONObject().apply {
            put("shortcode", shortcode)
            put("fetch_tagged_user_count", JSONObject.NULL)
            put("hoisted_comment_id", JSONObject.NULL)
            put("hoisted_reply_id", JSONObject.NULL)
        }

        val encodedVariables = URLEncoder.encode(variables.toString(), StandardCharsets.UTF_8.toString())
        val body = "variables=$encodedVariables&doc_id=$INSTAGRAM_DOCUMENT_ID"
        val requestBody = RequestBody.create("application/x-www-form-urlencoded".toMediaTypeOrNull(), body)

        val client = OkHttpClient()
        val request = Request.Builder()
            .url("https://www.instagram.com/graphql/query")
            .post(requestBody)
            .addHeader("Content-Type", "application/x-www-form-urlencoded")
            .addHeader("Cookie", mycookies ?: "")
            .addHeader("User-Agent", "Instagram 9.5.2 (iPhone7,2; iPhone OS 9_3_3; en_US; en-US; scale=2.00; 750x1334) AppleWebKit/420+")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("Request failed with status: ${response.code}")
            val jsonResponse = JSONObject(response.body?.string())
            return jsonResponse.getJSONObject("data").getJSONObject("xdt_shortcode_media").toString()
        }
    }

    fun fetchInstagramData(instagramUrl: String, cookies: String?) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val postData = scrapePost(instagramUrl, cookies)
                val postDataModel = InstagramPostDataNew.fromJson(postData)

                val ownerUsername = postDataModel.owner?.username ?: "unknown_user"
                myInstaUsername = ownerUsername

                val edges = postDataModel.edgeSidecarToChildren?.edges
                val pendingList = mutableListOf<PendingMedia>()

                if (!edges.isNullOrEmpty()) {
                    edges.forEachIndexed { index, edgeNode ->
                        edgeNode.node?.let { node ->
                            if (node.isVideo == true) {
                                node.videoURL?.let { videoUrl ->
                                    pendingList.add(PendingMedia(videoUrl, "$ownerUsername${iUtils.getVideoFilenameFromURL(videoUrl)}", ".mp4"))
                                }
                            } else {
                                val imageUrl = node.displayResources?.lastOrNull()?.src
                                imageUrl?.let {
                                    pendingList.add(PendingMedia(it, "$ownerUsername${iUtils.getImageFilenameFromURL(it)}", ".png"))
                                }
                            }
                        }
                    }
                } else {
                    if (postDataModel.isVideo == true) {
                        postDataModel.videoURL?.let { videoUrl ->
                            pendingList.add(PendingMedia(videoUrl, "${ownerUsername}_${iUtils.getVideoFilenameFromURL(videoUrl)}", ".mp4"))
                        }
                    } else {
                        val imageUrl = postDataModel.displayResources?.lastOrNull()?.src
                        imageUrl?.let {
                            pendingList.add(PendingMedia(it, "${ownerUsername}_${iUtils.getImageFilenameFromURL(it)}", ".png"))
                        }
                    }
                }

                if(pendingList.isNotEmpty()){
                    showPreviewUI(pendingList)
                } else {
                    showToast(resources.getString(R.string.somthing))
                    downloadInstagramImageOrVideoResponseOkhttp(instagramUrl)
                }

            } catch (e: Exception) {
                e.printStackTrace()
                downloadInstagramImageOrVideoResponseOkhttp(instagramUrl)
            }
        }
    }

    private fun showToast(message: String) {
        CoroutineScope(Dispatchers.Main).launch {
            Toast.makeText(myselectedActivity, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun downloadInstagramImageOrVideo_tikinfApi(URL: String?) {
        var myurl = URL ?: return
        try {
            myurl = iUtils.extractUrls(myurl)[0]
        } catch (_: Exception) {}
        DownloadVideosMain.Start(myselectedActivity, myurl.trim(), false)
        resetUI()
    }

    @Keep
    fun downloadInstagramImageOrVideoResponseOkhttp(URL: String?) {
        val safeUrl = URL ?: return
        object : Thread() {
            override fun run() {
                try {
                    val cookieJar: ClearableCookieJar = PersistentCookieJar(SetCookieCache(), SharedPrefsCookiePersistor(myselectedActivity))
                    val client: OkHttpClient = OkHttpClient.Builder().cookieJar(cookieJar).build()

                    val request: Request = Request.Builder()
                        .url("$safeUrl?__a=1&__d=dis")
                        .method("GET", null)
                        .header("Cookie", iUtils.myInstagramTempCookies ?: "")
                        .header("user-agent", iUtils.generateInstagramUserAgent() ?: "")
                        .build()
                    val response = client.newCall(request).execute()
                    val ressd = response.body?.string() ?: ""

                    var code = response.code
                    if (!ressd.contains("shortcode_media")) {
                        code = 400
                    }
                    if (code == 200) {
                        try {
                            val listType = object : TypeToken<ModelInstagramResponse?>() {}.type
                            val modelInstagramResponse: ModelInstagramResponse? = GsonBuilder().create().fromJson<ModelInstagramResponse>(ressd, listType)

                            val pendingList = mutableListOf<PendingMedia>()

                            if (modelInstagramResponse != null) {
                                val username = myInstaUsername ?: ""
                                if (modelInstagramResponse.modelGraphshortcode?.shortcode_media?.edge_sidecar_to_children != null) {
                                    val modelGetEdgetoNode: ModelGetEdgetoNode = modelInstagramResponse.modelGraphshortcode.shortcode_media.edge_sidecar_to_children
                                    val modelEdNodeArrayList: List<ModelEdNode> = modelGetEdgetoNode.modelEdNodes
                                    for (i in 0 until modelEdNodeArrayList.size) {
                                        if (modelEdNodeArrayList[i].modelNode.isIs_video) {
                                            val vUrl = modelEdNodeArrayList[i].modelNode.video_url ?: ""
                                            myVideoUrlIs = vUrl
                                            pendingList.add(PendingMedia(vUrl, username + iUtils.getVideoFilenameFromURL(vUrl), ".mp4"))
                                        } else {
                                            val pUrl = modelEdNodeArrayList[i].modelNode.display_resources?.lastOrNull()?.src ?: ""
                                            myPhotoUrlIs = pUrl
                                            pendingList.add(PendingMedia(pUrl, username + iUtils.getImageFilenameFromURL(pUrl), ".png"))
                                        }
                                    }
                                } else {
                                    val isVideo = modelInstagramResponse.modelGraphshortcode?.shortcode_media?.isIs_video == true
                                    if (isVideo) {
                                        val vUrl = modelInstagramResponse.modelGraphshortcode?.shortcode_media?.video_url ?: ""
                                        myVideoUrlIs = vUrl
                                        pendingList.add(PendingMedia(vUrl, username + iUtils.getVideoFilenameFromURL(vUrl), ".mp4"))
                                    } else {
                                        val pUrl = modelInstagramResponse.modelGraphshortcode?.shortcode_media?.display_resources?.lastOrNull()?.src ?: ""
                                        myPhotoUrlIs = pUrl
                                        pendingList.add(PendingMedia(pUrl, username + iUtils.getImageFilenameFromURL(pUrl), ".png"))
                                    }
                                }

                                if(pendingList.isNotEmpty()) {
                                    showPreviewUI(pendingList)
                                } else {
                                    downloadInstagramImageOrVideoResOkhttpM2(safeUrl)
                                }
                            } else {
                                downloadInstagramImageOrVideoResOkhttpM2(safeUrl)
                            }
                        } catch (e: Exception) {
                            downloadInstagramImageOrVideoResOkhttpM2(safeUrl)
                        }
                    } else {
                        downloadInstagramImageOrVideoResOkhttpM2(safeUrl)
                    }
                } catch (e: Throwable) {
                    e.printStackTrace()
                    downloadInstagramImageOrVideoResOkhttpM2(safeUrl)
                }
            }
        }.start()
    }

    @Keep
    fun downloadInstagramImageOrVideoResOkhttpM2(URL: String?) {
        val safeUrl = URL ?: return
        try {
            val cookieJar: ClearableCookieJar = PersistentCookieJar(SetCookieCache(), SharedPrefsCookiePersistor(myselectedActivity))
            val client: OkHttpClient = OkHttpClient.Builder().cookieJar(cookieJar).build()

            val request: Request = Request.Builder()
                .url(safeUrl.split("?").get(0) + "embed/captioned/?_fb_noscript=1")
                .method("GET", null)
                .build()
            val response = client.newCall(request).execute()
            val ss = response.body?.string() ?: ""

            if (response.code == 200) {
                try {
                    var doc: String = ss.substring(ss.indexOf("contextJSON"), ss.indexOf("[]}}}\"")) + "[]}}}"
                    doc = doc.replace("contextJSON\":\"", "")
                    doc = doc.substring(doc.indexOf("video_url"), doc.indexOf("video_view_count"))
                    doc = doc.substring(14, doc.length - 5)

                    val decodedHtml = StringEscapeUtils.unescapeHtml4(doc)
                    val finalUrl = StringEscapeUtils.unescapeJava(decodedHtml.replace("""\\\/""", "/")) ?: ""
                    myVideoUrlIs = finalUrl

                    if (finalUrl.isNotEmpty()) {
                        val username = myInstaUsername ?: ""
                        val pendingList = mutableListOf<PendingMedia>()
                        pendingList.add(PendingMedia(finalUrl, username + iUtils.getVideoFilenameFromURL(finalUrl), ".mp4"))
                        showPreviewUI(pendingList)
                    } else {
                        downloadgraminstagramapi(safeUrl)
                    }
                } catch (e: Exception) {
                    downloadgraminstagramapi(safeUrl)
                }
            } else {
                downloadgraminstagramapi(safeUrl)
            }
        } catch (e: Throwable) {
            e.printStackTrace()
            downloadgraminstagramapi(safeUrl)
        }
    }

    private fun showAdmobAds_int_video() {
        if (Constants.show_Ads && !BuildConfig.ISPRO) {
            if (nn == "nnn") {
                AdsManager.showVideoAdAdmobAsync(
                    requireActivity(),
                    { }, false
                )
            }
        }
    }

    private fun showAdmobAds() {
        if (Constants.show_Ads && !BuildConfig.ISPRO) {
            if (nn == "nnn") {
                AdsManager.showAdmobInterstitialAd(
                    activity as Activity?,
                    object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            super.onAdDismissedFullScreenContent()
                            AdsManager.loadInterstitialAdAsync((activity as Activity?)!!)
                        }
                    }, false
                )
            }
        }
    }

    private fun configureRxJavaErrorHandler() {
        RxJavaPlugins.setErrorHandler { e: Throwable ->
            if (e is UndeliverableException) { }
            if (e is InterruptedException) { return@setErrorHandler }
            Log.e("configureRxJavaErrorHandler", "Undeliverable exception received", e)
        }
    }

    private fun hideKeyboard(activity: Activity) {
        try {
            val inputManager = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val currentFocusedView = activity.currentFocus
            if (currentFocusedView != null) {
                inputManager.hideSoftInputFromWindow(currentFocusedView.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun createNotificationChannel(context: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val oreoNotification = OreoNotification(
                context,
                if (!MyFirebaseMessagingService.isWaku) MyFirebaseMessagingService.DefaultSoundString else MyFirebaseMessagingService.DefaultSoundWakuString
            )
        }
    }
}