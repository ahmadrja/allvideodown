/*
 * *
 * * Created by Syed Usama Ahmad on 3/10/23, 6:48 PM
 * * Copyright (c) 2023 . All rights reserved.
 * * Last modified 3/8/23, 12:53 PM
 *
 */

package com.allvideodown.socialdownloader.utils;

import static android.os.Environment.DIRECTORY_DOWNLOADS;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.Log;
import android.webkit.CookieManager;

import androidx.core.content.ContextCompat;

import com.allvideodown.socialdownloader.R;
import com.allvideodown.socialdownloader.receiver.DownloadBroadcastReceiver;

import java.io.File;
import java.lang.reflect.Method;

public class DownloadFileMain {
    public static DownloadManager downloadManager;
    public static long downloadID;

    // 🚀 STRICT FILENAME SANITIZER - "Unsuccessful" error yahi se theek hota hai
    private static String sanitizeFilename(String title, String ext) {
        String cutTitle = title != null ? title : "AIO_Download";

        // Remove bad extensions
        cutTitle = cutTitle.replace(".mp4", "").replace(".jpg", "").replace(".png", "");

        // Keep ONLY Alphabets, Numbers & Underscores
        cutTitle = cutTitle.replaceAll("[^a-zA-Z0-9_]", "_").replaceAll("_+", "_");

        if (cutTitle.length() > 50) {
            cutTitle = cutTitle.substring(0, 50);
        }

        // Return 100% Unique name
        return "AIO_" + cutTitle + "_" + System.currentTimeMillis() + ext;
    }

    public static void startDownloading(final Context context, String url, String title, String ext) {
        try {
            DownloadBroadcastReceiver.isFirstTimeDownload = false;

            if (url == null || url.trim().isEmpty()) {
                throw new IllegalArgumentException("Download URL is empty.");
            }

            // 🚀 URL CLEANUP - Taki koi broken link server block na kare
            url = url.replace("\"", "").trim();
            url = url.replace("\\/", "/");
            url = url.replace("\\u0026", "&");
            url = url.replace("&amp;", "&");
            if (url.startsWith("//")) {
                url = "https:" + url;
            }

            String finalFileName = sanitizeFilename(title, ext);
            Log.e("DownloadFileMain", "Downloading URL: " + url);
            Log.e("DownloadFileMain", "Saved As: " + finalFileName);

            downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
            Uri uri = Uri.parse(url);
            DownloadManager.Request request = new DownloadManager.Request(uri);

            request.setTitle(finalFileName);
            request.setDescription("Downloading via Premium Server...");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

            // 🚀 FIX: By-Pass 403 Forbidden Errors
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) {
                request.addRequestHeader("Cookie", cookie);
            }
            request.addRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36");
            request.addRequestHeader("Accept", "*/*");

            // MimeType setup
            String mimeType = "video/mp4";
            String subFolder = Constants.directoryInstaShoryDirectorydownload_videos;

            if (ext.equalsIgnoreCase(".jpg") || ext.equalsIgnoreCase(".jpeg") || ext.equalsIgnoreCase(".png")) {
                mimeType = "image/jpeg";
                subFolder = Constants.directoryInstaShoryDirectorydownload_images;
            } else if (ext.equalsIgnoreCase(".mp3") || ext.equalsIgnoreCase(".m4a")) {
                mimeType = "audio/mpeg";
                subFolder = Constants.directoryInstaShoryDirectorydownload_audio;
            }

            request.setMimeType(mimeType);

            // 🚀 ANDROID 11+ FILE SAVING LOGIC (No crashes anymore)
            // Constants me agar slash (/) hai to use manage karna
            if (subFolder != null && subFolder.startsWith("/")) {
                subFolder = subFolder.substring(1);
            }
            if (subFolder != null && !subFolder.endsWith("/")) {
                subFolder = subFolder + "/";
            }

            File saveDir = new File(Environment.getExternalStoragePublicDirectory(DIRECTORY_DOWNLOADS), subFolder);
            if (!saveDir.exists()) {
                saveDir.mkdirs();
            }

            request.setDestinationInExternalPublicDir(DIRECTORY_DOWNLOADS, subFolder + finalFileName);

            // Force refresh in Android 9 and below
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                request.allowScanningByMediaScanner();
            }

            // Start the download
            downloadID = downloadManager.enqueue(request);
            expandNotificationBar(context);

            ((Activity) context).runOnUiThread(() -> iUtils.ShowToast(context, "Download Started Successfully!"));

        } catch (Exception e) {
            e.printStackTrace();
            ((Activity) context).runOnUiThread(() -> iUtils.ShowToastError(context, "Download Failed: " + e.getMessage()));
        }
    }

    public static void expandNotificationBar(Context context) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.EXPAND_STATUS_BAR) != PackageManager.PERMISSION_GRANTED)
            return;
        try {
            @SuppressLint("WrongConstant") Object service = context.getSystemService("statusbar");
            Class<?> statusbarManager = Class.forName("android.app.StatusBarManager");
            Method expand = statusbarManager.getMethod("expandNotificationsPanel");
            expand.invoke(service);
        } catch (Exception e) {
            Log.e("StatusBar", e.toString());
        }
    }
}