/*
 * *
 * * Created by Syed Usama Ahmad
 * * Copyright (c) 2023 . All rights reserved.
 *
 */

package com.allvideodown.socialdownloader.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class GalleryStatusSaver extends Fragment {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Whatsapp Status Saver remove ho chuka hai,
        // isliye compile-time error fix karne ke liye hum yahan ek empty layout return kar rahe hain.
        return new FrameLayout(requireContext());
    }
}