package com.allvideodown.socialdownloader.interfaces;

public interface DataCallBackNewJetApi {

    void onResult(boolean result);
}
