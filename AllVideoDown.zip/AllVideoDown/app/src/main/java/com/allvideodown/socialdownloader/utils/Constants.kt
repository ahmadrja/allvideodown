/*
 * *
 * * Created by Syed Usama Ahmad
 * * Copyright (c) 2023 . All rights reserved.
 * *
 */

@file:Suppress("DEPRECATION")

package com.allvideodown.socialdownloader.utils

object Constants {

    //TODO NOTE: Should make it true if you have purchased admin panel, then add info here
    const val iSAdminAttached = false
    const val adminApiUrl: String = "https://adminvideodd.infusiblecoder.com/api"

    //TODO NOTE: Should make it false if you want to upload to the play-store
    const val showyoutube = false

    //TODO NOTE: if you want to hide subscription button you can make this false
    const val show_subscription = true

    //TODO NOTE: if you want to disable ads you can make this false
    const val show_Ads = true
    const val enableTestAds = true

    // Folder names and App Identifiers
    const val SAVE_FOLDER_NAME = "/Download/AIO_Status_Saver/"
    const val MY_ANDROID_10_IDENTIFIER_OF_FILE = "All_Video_Downloader_"
    const val MY_ANDROID_IDENTIFIER_OF_FILE_DL = "_All_Video_Downloader."

    const val directoryInstaShoryDirectorydownload_videos = "/InstaStory/videos/"
    const val directoryInstaShoryDirectorydownload_images = "/InstaStory/images/"
    const val directoryInstaShoryDirectorydownload_audio = "/InstaStory/audios/"

    const val PREF_APPNAME: String = "aiovidedownloader"
    const val PREF_CLIP: String = "tikVideoDownloader"

    // Whatsapp Folders (Kept for safe backward compatibility)
    const val FOLDER_NAME = "/WhatsApp/"
    const val FOLDER_NAME_Whatsappbusiness = "/WhatsApp Business/"
    const val FOLDER_NAME_Whatsapp_and11 = "/Android/media/com.whatsapp/WhatsApp/"
    const val FOLDER_NAME_Whatsapp_and11_B = "/Android/media/com.whatsapp.w4b/WhatsApp Business/"

}