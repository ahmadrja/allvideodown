/*
 * *
 * * Created by Syed Usama Ahmad on 3/14/23, 5:04 PM
 * * Copyright (c) 2023 . All rights reserved.
 * * Last modified 3/14/23, 5:01 PM
 *
 */

package com.allvideodown.socialdownloader.utils.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class DownloadWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        // Option 1 (Lite App) के लिए बैकग्राउंड डाउनलोड लॉजिक हटा दिया गया है।
        // अब डाउनलोडिंग सीधे वेबसाइट के थ्रू हैंडल हो रही है।
        return Result.success()
    }

    // Companion object को रखना जरूरी है ताकि दूसरी फाइल्स में कोई एरर ना आये
    companion object {
        const val urlKey = "url"
        const val nameKey = "name"
        const val formatIdKey = "formatId"
        const val acodecKey = "acodec"
        const val vcodecKey = "vcodec"
        const val taskIdKey = "taskId"
        const val ext = "ext"
    }
}