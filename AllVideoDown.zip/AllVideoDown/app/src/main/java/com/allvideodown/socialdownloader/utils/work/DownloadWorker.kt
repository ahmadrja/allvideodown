package com.allvideodown.socialdownloader.utils.work

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Environment
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.allvideodown.socialdownloader.R
import com.allvideodown.socialdownloader.services.MyFirebaseMessagingService
import com.allvideodown.socialdownloader.utils.Constants.directoryInstaShoryDirectorydownload_audio
import com.allvideodown.socialdownloader.utils.Constants.directoryInstaShoryDirectorydownload_images
import com.allvideodown.socialdownloader.utils.Constants.directoryInstaShoryDirectorydownload_videos
import com.allvideodown.socialdownloader.utils.iUtils
import com.allvideodown.socialdownloader.utils.iUtils.createFilenameWithJapneseAndOthers
import java.io.File

class DownloadWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    private val notificationManager =
        appContext.getSystemService(Context.NOTIFICATION_SERVICE) as
                NotificationManager?

    override suspend fun doWork(): Result {

        val url = inputData.getString(urlKey) ?: return Result.failure()
        val name = createFilenameWithJapneseAndOthers(inputData.getString(nameKey) ?: "download_file")
        val taskId = inputData.getString(taskIdKey) ?: "task_${System.currentTimeMillis()}"
        val ext = inputData.getString(ext) ?: "mp4"

        createNotificationChannel()
        val notificationId = id.hashCode()
        val notification = NotificationCompat.Builder(
            applicationContext,
            iUtils.myNotificationChannel
        )
            .setSmallIcon(R.drawable.ic_download_yellow)
            .setContentTitle(name)
            .setSound(null)
            .setOnlyAlertOnce(true)
            .setAutoCancel(false)
            .setContentText(applicationContext.getString(R.string.don_start))
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            setForegroundAsync(
                ForegroundInfo(
                    notificationId,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            )
        } else {
            setForegroundAsync(ForegroundInfo(notificationId, notification))
        }

        try {
            // डायरेक्टरी सेट करने का लॉजिक
            val file_v = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    .toString() + directoryInstaShoryDirectorydownload_videos
            )
            if (!file_v.exists()) file_v.mkdir()

            val file_i = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    .toString() + directoryInstaShoryDirectorydownload_images
            )
            if (!file_i.exists()) file_i.mkdir()

            val file_a = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    .toString() + directoryInstaShoryDirectorydownload_audio
            )
            if (!file_a.exists()) file_a.mkdir()

            /* * नोट: YoutubeDL को हटा दिया गया है।
             * Instagram और Facebook के लिए अब आपको Android के नेटिव DownloadManager
             * या PRDownloader का उपयोग करके डाउनलोड पास करना होगा।
             */
            Log.d("DownloadWorker", "Ready for Native Download.")

            // डाउनलोड पूरा होने का नोटिफिकेशन
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                MyFirebaseMessagingService.sendOreoNotification(
                    applicationContext,
                    applicationContext.resources.getString(R.string.app_name),
                    applicationContext.resources.getString(R.string.yourdoncomple)
                )
            } else {
                MyFirebaseMessagingService.sendNotification(
                    applicationContext,
                    applicationContext.resources.getString(R.string.app_name),
                    applicationContext.resources.getString(R.string.yourdoncomple)
                )
            }
        } catch (e: Exception) {
            Log.e("DownloadWorker Error", e.message.toString())
            e.printStackTrace()
            return Result.failure()
        }

        return Result.success()
    }

    private fun showProgress(
        id: Int,
        taskId: String,
        name: String,
        progress: Int,
        text: String
    ) {
        val intent = Intent(applicationContext, CancelReceiver::class.java)
            .putExtra("taskId", taskId)
            .putExtra("notificationId", id)

        val pendingIntent =
            PendingIntent.getBroadcast(
                applicationContext,
                0,
                intent,
                PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
            )
        val notification = NotificationCompat.Builder(
            applicationContext,
            iUtils.myNotificationChannel
        )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSmallIcon(R.drawable.ic_download_yellow)
            .setContentTitle(name)
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(text)
            )
            .setSound(null)
            .setOnlyAlertOnce(true)
            .setAutoCancel(false)
            .setProgress(100, progress, progress == -1)
            .addAction(
                R.drawable.ic_close_24dp,
                applicationContext.getString(R.string.cancel),
                pendingIntent
            )
            .setOngoing(true)
            .build()
        notificationManager?.notify(id, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            var notificationChannel =
                notificationManager?.getNotificationChannel(iUtils.myNotificationChannel)
            if (notificationChannel == null) {
                val channelName = applicationContext.getString(R.string.app_name)
                notificationChannel = NotificationChannel(
                    iUtils.myNotificationChannel,
                    channelName, NotificationManager.IMPORTANCE_LOW
                )
                notificationChannel.description = channelName
                notificationManager?.createNotificationChannel(notificationChannel)
            }
        }
    }

    companion object {
        const val urlKey = "url"
        const val nameKey = "name"
        const val formatIdKey = "formatId"
        const val acodecKey = "acodec"
        const val vcodecKey = "vcodec"
        const val taskIdKey = "taskId"
        const val ext = "ext"
    }
}