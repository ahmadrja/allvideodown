package com.allvideodown.socialdownloader.interfaces;

public interface VideoDownloader {

    String getVideoId(String link);

    void DownloadVideo();
}
