package com.allvideodown.socialdownloader.adapters;

import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import org.jetbrains.annotations.NotNull;

// यह क्लास अब अप्रचलित (Deprecated) हो चुकी है क्योंकि YoutubeDL हटा दिया गया है। 
// केवल Instagram और Facebook के नेटिव सपोर्ट के लिए इसे खाली (Empty) कर दिया गया है।

public class QualityBottomsheetAdapter extends RecyclerView.Adapter<QualityBottomsheetAdapter.ViewHolder> {

    public QualityBottomsheetAdapter() {
        // Empty Constructor
    }

    @NonNull
    @Override
    public QualityBottomsheetAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NotNull QualityBottomsheetAdapter.ViewHolder holder, final int position) {
        // Do Nothing
    }

    @Override
    public int getItemCount() {
        return 0; // 0 Items
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(View itemView) {
            super(itemView);
        }
    }
}