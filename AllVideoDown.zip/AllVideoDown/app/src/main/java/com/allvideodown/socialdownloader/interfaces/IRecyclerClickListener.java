package com.allvideodown.socialdownloader.interfaces;

import android.view.View;

public interface IRecyclerClickListener {
    void onClickRec(View view, int position);
}
