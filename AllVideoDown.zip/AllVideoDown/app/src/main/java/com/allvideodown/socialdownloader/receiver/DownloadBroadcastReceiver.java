/*
 * *
 * * Created by Syed Usama Ahmad
 * * Copyright (c) 2026 . All rights reserved.
 * * Updated: Phone Gallery Visibility Fix (Scans file after 100% completion)
 *
 */

package com.allvideodown.socialdownloader.receiver;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Log;

public class DownloadBroadcastReceiver extends BroadcastReceiver {
    public static boolean isFirstTimeDownload = false;

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        // 🚀 यह तब ट्रिगर होता है जब डाउनलोड 100% कम्पलीट हो जाए
        if (DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)) {
            long downloadId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, 0);
            DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Query query = new DownloadManager.Query();
            query.setFilterById(downloadId);

            Cursor cursor = downloadManager.query(query);
            if (cursor != null && cursor.moveToFirst()) {
                @SuppressLint("Range") int status = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));

                if (status == DownloadManager.STATUS_SUCCESSFUL) {

                    // Android 10+ (Content URI) को रियल File Path में बदलना
                    @SuppressLint("Range") String uriString = cursor.getString(cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));

                    if (uriString != null) {
                        try {
                            Uri uri = Uri.parse(uriString);
                            String filePath = null;

                            if ("file".equals(uri.getScheme())) {
                                filePath = uri.getPath();
                            } else {
                                // Content URI से असली File Path निकालना
                                Cursor mediaCursor = context.getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.DATA}, null, null, null);
                                if (mediaCursor != null && mediaCursor.moveToFirst()) {
                                    filePath = mediaCursor.getString(0);
                                    mediaCursor.close();
                                }
                            }

                            // 🚀 MEDIA SCANNER TRIGGER: यह फाइल को तुरंत फोन गैलरी में भेज देगा
                            if (filePath != null) {
                                MediaScannerConnection.scanFile(context,
                                        new String[]{filePath}, null,
                                        (path, scannedUri) -> Log.i("GalleryFix", "File successfully sent to Phone Gallery: " + path));
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
            if (cursor != null) {
                cursor.close();
            }
        }
    }
}