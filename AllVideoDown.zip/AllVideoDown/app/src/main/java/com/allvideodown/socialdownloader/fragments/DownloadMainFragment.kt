/*
 * *
 * * Created by Syed Usama Ahmad
 * * Copyright (c) 2023 . All rights reserved.
 *
 */

@file:Suppress("DEPRECATION", "NAME_SHADOWING")

package com.allvideodown.socialdownloader.fragments

import android.app.Activity
import android.app.ProgressDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import androidx.annotation.Keep
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.MobileAds
import com.allvideodown.socialdownloader.BuildConfig
import com.allvideodown.socialdownloader.R
import com.allvideodown.socialdownloader.activities.GalleryActivity
import com.allvideodown.socialdownloader.activities.MainActivity
import com.allvideodown.socialdownloader.databinding.FragmentDownloadBinding
import com.allvideodown.socialdownloader.utils.AdsManager
import com.allvideodown.socialdownloader.utils.Constants
import com.allvideodown.socialdownloader.utils.Constants.PREF_CLIP
import com.allvideodown.socialdownloader.utils.SharedPrefsMainApp
import com.allvideodown.socialdownloader.utils.iUtils
import com.allvideodown.socialdownloader.webservices.DownloadVideosMain
import java.util.concurrent.Executor

@Keep
class DownloadMainFragment : Fragment() {
    private var myselectedActivity: FragmentActivity? = null
    private var binding: FragmentDownloadBinding? = null
    private var nn: String? = "nnn"
    private var csRunning = false
    lateinit var progressDralogGenaratinglink: ProgressDialog
    private lateinit var prefEditor: SharedPreferences.Editor
    lateinit var pref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDownloadBinding.inflate(inflater, container, false)
        setActivityAfterAttached()
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (activity != null && isAdded) {
            hideKeyboard(requireActivity())
            nn = SharedPrefsMainApp(myselectedActivity).preferencE_inappads

            progressDralogGenaratinglink = ProgressDialog(myselectedActivity!!)
            progressDralogGenaratinglink.setMessage(resources.getString(R.string.genarating_download_link))
            progressDralogGenaratinglink.setCancelable(false)

            pref = myselectedActivity!!.getSharedPreferences(PREF_CLIP, 0)
            prefEditor = pref.edit()
            csRunning = pref.getBoolean("csRunning", false)
            prefEditor.apply()

            binding!!.ivHelp.setOnClickListener {
                try {
                    binding!!.etURL.text?.clear()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            binding!!.btnDownload.setOnClickListener {
                val url = binding!!.etURL.text.toString()
                DownloadVideo(url)
            }

            if (activity != null) {
                val mainActivity: MainActivity? = activity as? MainActivity
                val strtext: String? = mainActivity?.getMyData()
                if (!strtext.isNullOrEmpty()) {
                    mainActivity?.setmydata("")
                    binding!!.etURL.setText(strtext)
                    DownloadVideo(strtext)
                }
            }

            handleBioMetricTask()

            binding!!.ivLink.setOnClickListener {
                try {
                    val clipBoardManager = myselectedActivity!!.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val primaryClipData = clipBoardManager.primaryClip
                    if (primaryClipData != null && primaryClipData.itemCount > 0) {
                        val clip = primaryClipData.getItemAt(0)?.text.toString()
                        binding!!.etURL.text = Editable.Factory.getInstance().newEditable(clip)
                        DownloadVideo(clip)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            doAdsStuff()
        }
    }

    private fun doAdsStuff() {
        try {
            if (Constants.show_Ads && !BuildConfig.ISPRO && nn == "nnn") {
                MobileAds.initialize(requireActivity()) {
                    AdsManager.loadInterstitialAdAsync((activity as Activity?)!!)
                    AdsManager.loadVideoAdAdmobAsync(
                        (activity as Activity?)!!,
                        object : FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent()
                            }
                        })
                    LoadAdTaskDownload(myselectedActivity!!, binding!!.flAdplaceholder).execute()
                }
            } else {
                binding!!.flAdplaceholder.visibility = View.GONE
            }
        } catch (_: Exception) {}
    }

    private fun handleBioMetricTask() {
        try {
            val executor: Executor = ContextCompat.getMainExecutor(myselectedActivity!!)
            val biometricPrompt =
                BiometricPrompt(
                    myselectedActivity!!,
                    executor,
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                            super.onAuthenticationError(errorCode, errString)
                        }

                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                            super.onAuthenticationSucceeded(result)
                            startActivity(Intent(myselectedActivity, GalleryActivity::class.java))
                        }
                    })

            val promptInfo: BiometricPrompt.PromptInfo =
                BiometricPrompt.PromptInfo.Builder().setTitle("Verify Identity")
                    .setDescription("Use your fingerprint or device credentials to Access Gallery")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
                    .build()

            binding!!.rvGallery.setOnClickListener {
                try {
                    val prefs: SharedPreferences = myselectedActivity!!.getSharedPreferences("whatsapp_pref", Context.MODE_PRIVATE)
                    val isBioEnabled = prefs.getBoolean("isBio", false)
                    if (isBioEnabled) {
                        biometricPrompt.authenticate(promptInfo)
                    } else {
                        startActivity(Intent(myselectedActivity, GalleryActivity::class.java))
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    startActivity(Intent(myselectedActivity, GalleryActivity::class.java))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            binding!!.rvGallery.setOnClickListener {
                startActivity(Intent(myselectedActivity, GalleryActivity::class.java))
            }
        }
    }

    class LoadAdTaskDownload(private val context: Activity, private val frameLayout: FrameLayout) :
        AsyncTask<Void, Void, Unit>() {
        @Deprecated("Deprecated in Java")
        override fun doInBackground(vararg params: Void?) {
            AdsManager.loadAdmobNativeAdAsync(context, frameLayout)
        }
    }

    override fun onResume() {
        super.onResume()
        if (activity != null) {
            val mainActivity: MainActivity? = activity as? MainActivity
            val strtext: String? = mainActivity?.getMyData()
            if (!strtext.isNullOrEmpty()) {
                mainActivity?.setmydata("")
                binding!!.etURL.setText(strtext)
                DownloadVideo(strtext)
            }
        }
    }

    fun DownloadVideo(url1: String) {
        hideKeyboard(requireActivity())

        if (TextUtils.isEmpty(url1.trim())) {
            iUtils.ShowToast(myselectedActivity, myselectedActivity!!.resources?.getString(R.string.enter_valid))
            return
        }

        var url = url1
        try {
            val extracted = iUtils.extractUrls(url1)
            if (extracted.isNotEmpty()) {
                url = extracted[0]
            }
        } catch (_: Exception) {}

        if (!iUtils.checkURL(url.trim())) {
            iUtils.ShowToast(myselectedActivity, myselectedActivity!!.resources?.getString(R.string.enter_valid))
            return
        }

        // Display Interstitial/Video Ad before processing to maximize revenue
        val randInt = iUtils.getRandomNumber(2)
        if (randInt == 0) {
            showAdmobAds()
        } else {
            showAdmobAds_int_video()
        }

        // Direct call to Java API File which handles IN-APP Preview BottomSheet
        if (url.contains("instagram.com") || url.contains("facebook.com") || url.contains("fb.watch") || url.contains("fb.com")) {
            if (!myselectedActivity!!.isFinishing) {
                progressDralogGenaratinglink.show()
            }
            DownloadVideosMain.Start(myselectedActivity, url.trim(), false)
        } else {
            iUtils.ShowToast(myselectedActivity, "Only Instagram and Facebook are supported.")
        }
    }

    private fun setActivityAfterAttached() {
        try {
            if (activity != null && isAdded) {
                myselectedActivity = activity
            }
        } catch (e: Exception) {
            myselectedActivity = requireActivity()
            e.printStackTrace()
        }
    }

    private fun showAdmobAds_int_video() {
        if (Constants.show_Ads && !BuildConfig.ISPRO) {
            if (nn == "nnn") {
                AdsManager.showVideoAdAdmobAsync(requireActivity(), { }, false)
            }
        }
    }

    private fun showAdmobAds() {
        if (Constants.show_Ads && !BuildConfig.ISPRO) {
            if (nn == "nnn") {
                AdsManager.showAdmobInterstitialAd(
                    activity as Activity?,
                    object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            super.onAdDismissedFullScreenContent()
                            AdsManager.loadInterstitialAdAsync((activity as Activity?)!!)
                        }
                    }, false
                )
            }
        }
    }

    private fun hideKeyboard(activity: Activity) {
        try {
            val inputManager = activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            val currentFocusedView = activity.currentFocus
            if (currentFocusedView != null) {
                inputManager.hideSoftInputFromWindow(currentFocusedView.windowToken, InputMethodManager.HIDE_NOT_ALWAYS)
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}