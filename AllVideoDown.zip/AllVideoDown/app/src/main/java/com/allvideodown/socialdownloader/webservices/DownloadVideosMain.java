/*
 * *
 * * Updated for Lite App & Advanced UX
 * * Connected to Premium Custom API (allvd.api-cdn-premium.click)
 * * ADDED: Play Video on Thumbnail Click Feature
 * *
 */

package com.allvideodown.socialdownloader.webservices;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.allvideodown.socialdownloader.R;
import com.allvideodown.socialdownloader.utils.DownloadFileMain;
import com.allvideodown.socialdownloader.utils.GlideApp;
import com.allvideodown.socialdownloader.utils.iUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URLEncoder;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@SuppressLint("all")
public class DownloadVideosMain {

    public static Activity Mcontext;
    public static ProgressDialog pd;
    public static SharedPreferences prefs;
    public static Boolean fromService;
    static String myURLIS = "";

    @RequiresApi(api = Build.VERSION_CODES.CUPCAKE)
    public static void Start(final Activity context, String websiteUrl, Boolean service) {
        try {
            Mcontext = context;
            fromService = service;
            Log.i("LOGClipboard111111 clip", "work 2");

            try {
                websiteUrl = iUtils.extractUrls(websiteUrl).get(0);
            } catch (Exception ignored) {
            }

            myURLIS = websiteUrl;
            if (!fromService) {
                pd = new ProgressDialog(context);
                pd.setMessage(Mcontext.getResources().getString(R.string.genarating_download_link));
                pd.setCancelable(false);
                pd.show();
            }

            // 🚀 Hitting Your Premium API Backend Directly
            getDataFromAllVideoDownNet(websiteUrl, result -> {
                Handler mainHandler = new Handler(Looper.getMainLooper());
                mainHandler.post(() -> {
                    if (!result) {
                        dismissMyDialogErrorToastForBlockedWebsitePanel();
                    } else {
                        dismissMyDialog();
                    }
                });
            });

        } catch (Exception e) {
            e.printStackTrace();
            dismissMyDialogErrortoast();
        }
    }

    // 🚀 CUSTOM API HANDLER FOR YOUR WEBSITE (allvd.api-cdn-premium.click)
    public static void getDataFromAllVideoDownNet(String videoUrl, DataCallBack resultCallback) {
        try {
            // URL Encode (Zaroori hai URLs pass karne ke liye)
            String encodedUrl = URLEncoder.encode(videoUrl, "UTF-8");

            // 🛑 IMPORTANT: Apna HAR file ka exact path yahan daalein!
            String myApiUrl = "https://allvd.api-cdn-premium.click/api/analyze?url=" + encodedUrl;

            Log.e("API_CALL", "Hitting custom API: " + myApiUrl);

            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(myApiUrl)
                    .addHeader("User-Agent", "AIO-App-Client")
                    .addHeader("Accept", "application/json") // Ensure JSON aayega
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    new Handler(Looper.getMainLooper()).post(() -> resultCallback.onResult(false));
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful() && response.body() != null) {
                        String responseData = response.body().string();
                        Log.e("API_RESPONSE", responseData); // 👈 Is se Logcat me response check kar sakte hain

                        try {
                            JSONObject jsonObject = new JSONObject(responseData);
                            JSONArray mymedias = new JSONArray();
                            String title = "AllVideoDown_Media";

                            // 🛠️ SMART PARSING LOGIC: Ye automatically data dhundh lega
                            if (jsonObject.has("title")) {
                                title = jsonObject.getString("title");
                            } else if (jsonObject.has("meta") && jsonObject.getJSONObject("meta").has("title")) {
                                title = jsonObject.getJSONObject("meta").getString("title");
                            }

                            // URL nikalna - multiple patterns cover kiye hain
                            if (jsonObject.has("medias")) {
                                mymedias = jsonObject.getJSONArray("medias");
                            } else if (jsonObject.has("links")) {
                                mymedias = jsonObject.getJSONArray("links");
                            } else if (jsonObject.has("url")) {
                                JSONObject mediaObj = new JSONObject();
                                mediaObj.put("url", jsonObject.getString("url"));
                                mediaObj.put("type", "video");
                                mymedias.put(mediaObj);
                            } else if (jsonObject.has("sd")) {
                                JSONObject mediaObj = new JSONObject();
                                mediaObj.put("url", jsonObject.getString("sd"));
                                mediaObj.put("type", "video");
                                mymedias.put(mediaObj);
                            } else if (jsonObject.has("hd")) {
                                JSONObject mediaObj = new JSONObject();
                                mediaObj.put("url", jsonObject.getString("hd"));
                                mediaObj.put("type", "video");
                                mymedias.put(mediaObj);
                            }

                            // Final execution
                            if (mymedias.length() > 0) {
                                // Title me se emoji aur special chars hata diye
                                String cleanTitle = title.replaceAll("[^a-zA-Z0-9_\\-]", "_");
                                String finalTitle = cleanTitle + "_" + System.currentTimeMillis();
                                JSONArray finalMedias = mymedias;

                                new Handler(Looper.getMainLooper()).post(() -> {
                                    showUniversalMultiplePreviewDialog(Mcontext, finalMedias, finalTitle);
                                    resultCallback.onResult(true);
                                });
                            } else {
                                new Handler(Looper.getMainLooper()).post(() -> resultCallback.onResult(false));
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                            new Handler(Looper.getMainLooper()).post(() -> resultCallback.onResult(false));
                        }
                    } else {
                        Log.e("API_ERROR", "Code: " + response.code());
                        new Handler(Looper.getMainLooper()).post(() -> resultCallback.onResult(false));
                    }
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            resultCallback.onResult(false);
        }
    }

    // Callback Interface
    public interface DataCallBack {
        void onResult(boolean result);
    }


    // =======================================================
    // 🚀 UNIVERSAL PREVIEW DIALOG (Before Download)
    // =======================================================
    public static void showUniversalMultiplePreviewDialog(Activity context, JSONArray mymedias, String title) {
        try {
            BottomSheetDialog dialog = new BottomSheetDialog(context);
            View view = LayoutInflater.from(context).inflate(R.layout.bottomsheet_quality_layout, null);

            Button btncancel = view.findViewById(R.id.btncancel_bottomsheet);
            Button btndownload = view.findViewById(R.id.btnopen_bottomsheet);
            TextView tvSource = view.findViewById(R.id.source_bottomsheet);
            TextView tvTitle = view.findViewById(R.id.bottomsheet_title);
            TextView tvDuration = view.findViewById(R.id.bottomsheet_duration);
            ImageView ivThumb = view.findViewById(R.id.bottomsheet_thumbnail);

            // Hide Recycler views since we have direct links
            if(view.findViewById(R.id.recqualitybottomsheet) != null) view.findViewById(R.id.recqualitybottomsheet).setVisibility(View.GONE);
            if(view.findViewById(R.id.recqualitybottomsheet_aud) != null) view.findViewById(R.id.recqualitybottomsheet_aud).setVisibility(View.GONE);
            tvDuration.setVisibility(View.GONE);

            String ctaText = mymedias.length() > 1 ? "Download All (" + mymedias.length() + ")" : "Download Now";
            btndownload.setText(ctaText);

            tvTitle.setText(Html.fromHtml("Title: <font color='red'>" + title + "</font>"));
            tvSource.setText(Html.fromHtml("Source: <font color='red'>AllVideoDown.net (Premium)</font>"));

            // Set Thumbnail smartly
            JSONObject firstMedia = mymedias.getJSONObject(0);
            String firstUrl = firstMedia.has("url") ? firstMedia.getString("url") : "";

            if(firstUrl.isEmpty() && firstMedia.has("download")) {
                firstUrl = firstMedia.getString("download"); // Kuch APIs "download" key bhejti hain url ki jagah
            }

            GlideApp.with(context)
                    .load(firstUrl)
                    .placeholder(R.drawable.ic_appicon_pro)
                    .into(ivThumb);

            // 🚀 NEW FEATURE: Play Video/Show Image on Thumbnail Click
            String finalFirstUrl = firstUrl;
            ivThumb.setOnClickListener(v -> {
                try {
                    String ext = finalFirstUrl.contains(".jpg") || finalFirstUrl.contains(".png") ? "image/*" : "video/*";
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.parse(finalFirstUrl), ext);
                    context.startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                    iUtils.ShowToast(context, "No media player found on this device.");
                }
            });

            btncancel.setOnClickListener(v -> dialog.cancel());

            // Handle Download Action
            btndownload.setOnClickListener(v -> {
                dialog.dismiss();
                try {
                    for (int i = 0; i < mymedias.length(); i++) {
                        JSONObject mediaItem = mymedias.getJSONObject(i);

                        String mediaUrl = "";
                        if(mediaItem.has("url")) mediaUrl = mediaItem.getString("url");
                        else if(mediaItem.has("download")) mediaUrl = mediaItem.getString("download"); // Fallback key

                        mediaUrl = mediaUrl.trim();

                        String ext = ".mp4"; // Default
                        if (mediaUrl.contains(".jpg") || mediaUrl.contains(".png")) {
                            ext = ".jpg";
                        } else if (mediaItem.has("type") && mediaItem.getString("type").equalsIgnoreCase("image")) {
                            ext = ".jpg";
                        } else if (mediaItem.has("type") && mediaItem.getString("type").equalsIgnoreCase("audio")) {
                            ext = ".mp3";
                        }

                        String finalName = mymedias.length() > 1 ? title + "_part" + (i+1) : title;
                        DownloadFileMain.startDownloading(context, mediaUrl, finalName, ext);
                    }
                    iUtils.ShowToast(context, "Downloading via Premium Server...");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });

            // Expand bottom sheet
            dialog.setOnShowListener(d -> {
                BottomSheetDialog bottomSheet = (BottomSheetDialog) d;
                View bottomSheetInternal = bottomSheet.findViewById(com.google.android.material.R.id.design_bottom_sheet);
                if (bottomSheetInternal != null) {
                    BottomSheetBehavior.from(bottomSheetInternal).setState(BottomSheetBehavior.STATE_EXPANDED);
                }
            });

            dialog.setContentView(view);
            dialog.show();
            dismissMyDialog();
        } catch (Exception e) {
            dismissMyDialogErrortoast();
        }
    }

    public static void dismissMyDialog() {
        if (pd != null && pd.isShowing() && !fromService && Mcontext != null && !((Activity) Mcontext).isFinishing()) {
            pd.dismiss();
        }
    }

    public static void dismissMyDialogErrortoast() {
        if (pd != null && pd.isShowing() && !fromService && Mcontext != null && !((Activity) Mcontext).isFinishing()) {
            pd.dismiss();
            Mcontext.runOnUiThread(() -> iUtils.ShowToastError(Mcontext, Mcontext.getResources().getString(R.string.somthing)));
        }
    }

    public static void dismissMyDialogErrorToastForBlockedWebsitePanel() {
        if (pd != null && pd.isShowing() && !fromService && Mcontext != null && !((Activity) Mcontext).isFinishing()) {
            pd.dismiss();
            Mcontext.runOnUiThread(() -> iUtils.ShowToastError(Mcontext, "Invalid Link or API is Currently Down"));
        }
    }
}