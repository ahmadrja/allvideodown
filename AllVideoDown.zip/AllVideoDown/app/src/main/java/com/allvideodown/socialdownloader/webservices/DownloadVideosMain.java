/*
 * *
 * * Created by Syed Usama Ahmad
 * * Copyright (c) 2023 . All rights reserved.
 *
 */

package com.allvideodown.socialdownloader.webservices;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;

import androidx.annotation.RequiresApi;

import com.allvideodown.socialdownloader.R;
import com.allvideodown.socialdownloader.utils.iUtils;

@SuppressLint("all")
public class DownloadVideosMain {

    public static Activity Mcontext;
    public static ProgressDialog pd;
    public static Boolean fromService;
    static String myURLIS = "";

    @RequiresApi(api = android.os.Build.VERSION_CODES.CUPCAKE)
    public static void Start(final Activity context, String websiteUrl, Boolean service) {
        try {
            Mcontext = context;
            fromService = service;

            try {
                websiteUrl = iUtils.extractUrls(websiteUrl).get(0);
            } catch (Exception ignored) { }

            myURLIS = websiteUrl.trim();

            if (myURLIS.contains("instagram.com")) {
                callInstagramAPI(myURLIS);
            } else if (myURLIS.contains("facebook.com") || myURLIS.contains("fb.watch") || myURLIS.contains("fb.com")) {
                callFacebookAPI(myURLIS);
            } else {
                dismissMyDialogErrortoast();
                iUtils.ShowToastError(Mcontext, "Only Instagram and Facebook are supported.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            dismissMyDialogErrortoast();
        }
    }

    public static void dismissMyDialog() {
        if (Mcontext != null && !Mcontext.isFinishing()) {
            try {
                com.allvideodown.socialdownloader.fragments.DownloadMainFragment fragment =
                        (com.allvideodown.socialdownloader.fragments.DownloadMainFragment)
                                ((androidx.appcompat.app.AppCompatActivity) Mcontext).getSupportFragmentManager().getFragments().get(0);

                if (fragment != null && fragment.progressDralogGenaratinglink != null && fragment.progressDralogGenaratinglink.isShowing()) {
                    fragment.progressDralogGenaratinglink.dismiss();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void dismissMyDialogErrortoast() {
        dismissMyDialog();
        if (Mcontext != null && !Mcontext.isFinishing()) {
            Mcontext.runOnUiThread(() -> iUtils.ShowToastError(Mcontext, Mcontext.getResources().getString(R.string.somthing)));
        }
    }

    // Call Instagram Downloader
    private static void callInstagramAPI(String url) {
        try {
            InstagramVideoDownloader downloader = new InstagramVideoDownloader(Mcontext, url);
            downloader.DownloadVideo();
        } catch (Exception e) {
            e.printStackTrace();
            dismissMyDialogErrortoast();
        }
    }

    // Call Facebook Downloader
    private static void callFacebookAPI(String url) {
        try {
            // यहाँ '0' पास करना अनिवार्य है।
            FbVideoDownloader downloader = new FbVideoDownloader(Mcontext, url, 0);
            downloader.DownloadVideo();
        } catch (Exception e) {
            e.printStackTrace();
            dismissMyDialogErrortoast();
        }
    }
}