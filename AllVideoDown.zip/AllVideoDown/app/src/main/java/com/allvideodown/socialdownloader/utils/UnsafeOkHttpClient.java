package com.allvideodown.socialdownloader.utils;


import android.annotation.SuppressLint;

import java.io.IOException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;

public class UnsafeOkHttpClient {

    public static OkHttpClient getUnsafeOkHttpClient() {
        try {
            @SuppressLint("CustomX509TrustManager") final TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        @SuppressLint("TrustAllX509TrustManager")
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {
                        }


                        @SuppressLint("TrustAllX509TrustManager")
                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {
                        }


                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };


            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());


            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();


            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory, (X509TrustManager) trustAllCerts[0]);
            builder.hostnameVerifier((hostname, session) -> true);
            // Set timeouts
            builder.connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS); // Connection timeout
            builder.readTimeout(30, java.util.concurrent.TimeUnit.SECONDS);    // Read timeout
            builder.writeTimeout(30, java.util.concurrent.TimeUnit.SECONDS);   // Write timeout

            // Add logging interceptor for debugging
            HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
            loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            builder.addInterceptor(loggingInterceptor);

            // Add an interceptor to add custom headers
            builder.addInterceptor(chain -> {
                Request originalRequest = chain.request();
                Request modifiedRequest = originalRequest.newBuilder()
                        .addHeader("crossorigin", "anonymous")
                        .build();
                try {
                    return chain.proceed(modifiedRequest);
                } catch (IOException e) {
                    // Log the error and rethrow if needed
                    // This helps in debugging issues related to network problems
                    throw new IOException("Network request failed: " + e.getMessage(), e);
                }
            });

            return builder.build();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}