package com.allvideodown.socialdownloader.interfaces;

public interface OnClickFileDeleteListner {

    void delFile(String path);
}
