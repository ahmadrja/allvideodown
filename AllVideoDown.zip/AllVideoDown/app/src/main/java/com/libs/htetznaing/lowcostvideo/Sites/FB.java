package com.libs.htetznaing.lowcostvideo.Sites;

import static com.libs.htetznaing.lowcostvideo.Utils.FacebookUtils.getFbLink;
import static com.libs.htetznaing.lowcostvideo.Utils.Utils.putModel;

import com.libs.androidnetworking.AndroidNetworking;
import com.libs.androidnetworking.error.ANError;
import com.libs.androidnetworking.interfaces.StringRequestListener;
import com.libs.htetznaing.lowcostvideo.LowCostVideo;
import com.libs.htetznaing.lowcostvideo.Model.XModel;

import java.util.ArrayList;

/*
This is direct link getter for Facebook
    By
Khun Htetz Naing
 */

public class FB {
    public static void fetch(String url, final LowCostVideo.OnTaskCompleted onTaskCompleted) {
        AndroidNetworking.post("https://fdown.net/download.php")
                .addBodyParameter("URLz", "https://www.facebook.com/video.php?v=" + url)
                .addHeaders("User-agent", LowCostVideo.agent)
                .build()
                .getAsString(new StringRequestListener() {
                    @Override
                    public void onResponse(String response) {
                        ArrayList<XModel> xModels = new ArrayList<>();
                        String sd = getFbLink(response, false);
                        if (sd != null) {
                            putModel(sd, "SD", xModels);
                        }
                        String hd = getFbLink(response, true);
                        if (hd != null) {
                            putModel(hd, "HD", xModels);
                        }
                        if (xModels.isEmpty()) {
                            onTaskCompleted.onError();
                        } else onTaskCompleted.onTaskCompleted(xModels, true);
                    }

                    @Override
                    public void onError(ANError anError) {
                        onTaskCompleted.onError();
                    }
                });
    }
}
